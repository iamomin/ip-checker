CONF_FILE = 'config.ini'
TIME_FORMAT = '%H:%M:%S'
API_URL = 'https://ifconfig.co/json'
